import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget
from PyQt6.QtWebEngineWidgets import QWebEngineView


class TestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("QWebEngineView Test")
        self.setGeometry(100, 100, 600, 400)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        self.create_button = QPushButton("Create WebView")
        self.create_button.clicked.connect(self.create_web_view)
        layout.addWidget(self.create_button)

        self.web_view = None

    def create_web_view(self):
        if self.web_view is None:
            print("Creating QWebEngineView")
            self.web_view = QWebEngineView(self)
            self.web_view.setHtml("<html><body><h1>Hello, World!</h1></body></html>")
            layout = self.centralWidget().layout()
            layout.addWidget(self.web_view)
        else:
            print("QWebEngineView already exists")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TestWindow()
    window.show()
    sys.exit(app.exec())
