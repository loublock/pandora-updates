"""

"""
from threading import Event
from pandora.GUI.pyqtImport import *
from pandora.datatypes import Point


class IPC:
    # init threads
    t_create_pl = None
    t_move_path = None
    t_socket_recv = None
    t_socket_send = None
    t_single_pos_drive = None
    t_maps_load_image = None
    t_pose_calculation = None
    t_path_correction = None
    t_auto_connect = None
    t_simulate_controller_artificial = None
    t_simulate_controller_live = None
    t_camera_get_image = None
    t_camera_process_image = None
    t_led_control = None
    t_simulate_images = None
    t_cmm_move = None
    t_hexapod_mode = None
    t_supervisor = None
    t_analyze_data = None
    t_calibration = None
    t_serialread_temp = None
    t_gcode_for_extruder = None
    t_serial_read_extruder = None
    t_neural_network = None
    t_position_calculation = None

    # Signals
    s_change_maps_mode = QtCore.pyqtSignal(bool)
    s_change_led_mode = QtCore.pyqtSignal(bool)
    # Close application signal
    s_close_PCAPS = QtCore.pyqtSignal(object, object)
    # set index of current planned pose in spd mode for maps
    s_set_current_planned_idx = QtCore.pyqtSignal(int)
    # set the robot ts as the maps ts to sync both
    s_sync_timestamps = QtCore.pyqtSignal(float)
    s_set_cmm_pos = QtCore.pyqtSignal(Point)
    # signal to stop MAPS from outside the main
    s_stop_MAPS = QtCore.pyqtSignal()

    # global thread killer event
    e_thread_kill = Event()
    # event to start/stop the calculation of pos and pose simultaneously
    e_calculation = Event()
    # event to start/stop analyzing data
    e_analyze = Event()
    # load_image event
    e_load_images = Event()
    # simulate_image event
    e_simulate_image = Event()
    # cam image event
    e_camera = Event()
    # event to start/stop the LED control thread
    e_led_thread = Event()
    # start the path creation
    e_path_creation = Event()
    # hexapod poll mode thread event
    e_hexapod_poll_mode = Event()
    # event to start/stop CMM mode
    e_CMM_move = Event()
    # enable path correction
    e_path_correction = Event()
    # start/reset robot moveL queued
    e_robot_move_path = Event()
    # global event to inform threads, that the robot movement has end. Emitted by robot controller.
    # is only set after the machine drove at least once and stays active until the machine is started again
    e_end_of_drive = Event()
    # event to tell path correction the robot movement hast been started and the timestamps can be synchronised now
    e_start_of_drive = Event()
    # start event
    e_start_MAPS = Event()
    # for single point drive mode
    e_single_point_drive = Event()
    # reset analyze data event
    e_reset_analyze = Event()
    # start the calibration thread. In the thread we check which calibration (CC or KS) was selected
    e_calibration_MAPS = Event()
    # event to signal that the calibration is done
    e_calibration_MAPS_done = Event()
    # event to load the calibration values from the xml file (transformation matrix, chamber constant and offset)
    e_load_xml = Event()
    # event to signal that the data us fully analyzed
    # Image acq. done
    # MAPS_calculation done
    # MAPS_pose_calculation done
    e_pose_calc_complete = Event()
    # MAPS_analyze done
    e_data_complete = Event()
    # cameras image acquisition signals that an image was taken
    e_image_acquired = Event()
    # event to trigger whenever a position was calculated (triggered in analyze)
    e_image_analyzed = Event()
    # event to tell that the spd mode is done. useful to trigger the start of the calibration calculations
    e_single_point_drive_done = Event()
    # analyze thread signals that the calculated maps pose is invalid
    e_analyze_failed = Event()
    # tell led control to toggle next led
    e_toggle_next_led = Event()
    # event to stop the asynchronous camera stream
    e_stop_camera_stream = Event()
    # start the neural network training
    e_neural_network = Event()
    # position calculation thread is busy or not
    e_pos_calc_busy = Event()
    # pose calculation thread is budy or not
    e_pose_calc_busy = Event()
    # take the next image in a LED-image-analyze routine (liveview and simulation)
    e_take_image = Event()
    # signal that an image was saved to the drive
    e_image_saved = Event()
    e_image_saved.set()

    def __init__(self):
        super(IPC, self).__init__()


