from pandora.app import main
import pandora.files_directories.organizeDirectories as Directories
from OTA_updater.bootstrap_launcher import main as bootstrap_main
import os
if __name__ == '__main__':
    Directories.create_measurement_directories()

    # run pandora
    try:
        from OTA_updater.bootstrap_launcher import main as bootstrap_main
        print("Running Bootstrap Launcher!")
        bootstrap_main()
    except ImportError:
        # Fallback if update system not available (development mode)
        print("Bootstrap launcher not found, running app directly...")
        from pandora.app import main

        main()