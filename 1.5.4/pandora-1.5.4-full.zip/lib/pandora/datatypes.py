import copy
from math import cos, sin
from PIL import Image
from threading import Event
import scipy.interpolate as spi
import pandas as pd

from pandora.GLOBALS import *
from pandora.basicMath import Scalar, Vector

Image.MAX_IMAGE_PIXELS = 933120000


class Pos:
    def __init__(self, x=0.0, y=0.0, z=0.0):
        super(Pos, self).__init__()

        self.x = x
        self.y = y
        self.z = z

    def __add__(self, other):
        x = self.x + other.x
        y = self.y + other.y
        z = self.z + other.z

        return Pos(x, y, z)

    def __sub__(self, other):
        x = self.x - other.x
        y = self.y - other.y
        z = self.z - other.z

        return Pos(x, y, z)

    def __truediv__(self, other):
        """
        Override divide method to divide x, y and z by a value.
        :param other:
        :return:
        """
        new_value = Pos()
        new_value.x = self.x / other
        new_value.y = self.y / other
        new_value.z = self.z / other

        return new_value

    def to_scalar(self) -> Scalar:
        scalar = Scalar()

        scalar.x = self.x
        scalar.y = self.y
        scalar.z = self.z
        return scalar

    def set_nans(self) -> None:
        self.x = np.nan
        self.y = np.nan
        self.z = np.nan


class Orient:
    def __init__(self, q0=1.0, q1=0.0, q2=0.0, q3=0.0):
        super(Orient, self).__init__()

        self.q0 = q0
        self.q1 = q1
        self.q2 = q2
        self.q3 = q3

    def __mul__(self, other):
        o = Orient()
        o.q0 = self.q0 * other.q0 - self.q1 * other.q1 - self.q2 * other.q2 - self.q3 * other.q3
        o.q1 = self.q0 * other.q1 + self.q1 * other.q0 + self.q2 * other.q3 - self.q3 * other.q2
        o.q2 = self.q0 * other.q2 - self.q1 * other.q3 + self.q2 * other.q0 + self.q3 * other.q1
        o.q3 = self.q0 * other.q3 + self.q1 * other.q2 - self.q2 * other.q1 + self.q3 * other.q0
        return o

    def quaternion_to_euler(self):
        """
        Converts quaternions to euler angles (adjusted to ABB systems).
        :return: Euler angles
        """
        (w, x, y, z) = (self.q0, self.q1, self.q2, self.q3)
        t0 = +2.0 * (w * x + y * z)
        t1 = +1.0 - 2.0 * (x * x + y * y)
        roll = math.atan2(t0, t1)

        t2 = +2.0 * (w * y - z * x)
        t2 = +1.0 if t2 > +1.0 else t2
        t2 = -1.0 if t2 < -1.0 else t2
        pitch = math.asin(t2)

        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        yaw = math.atan2(t3, t4)
        e_angles = EulerAngles(yaw=yaw, pitch=pitch, roll=roll, order='xyz')

        return e_angles

    def get_quaternion(self, n: Scalar, theta: float):
        """
        Creating a quaterion from vector and rotation.
        """
        v = Vector(p2=n)

        c = cos(theta * 0.5)
        s = sin(theta * 0.5)

        qw = c
        q1 = v.direction.x * s
        q2 = v.direction.y * s
        q3 = v.direction.z * s

        return Orient(qw, q1, q2, q3)

    def quaternion_from_matrix33(self, M):
        """
        ..
        """
        a1 = math.sqrt(M[0, 0] + M[1, 1] + M[2, 2] + 1) * 0.5
        a2 = math.sqrt(M[0, 0] - M[1, 1] - M[2, 2] + 1) * 0.5 * np.sign(M[2, 1] - M[1, 2])
        a3 = math.sqrt(M[1, 1] - M[0, 0] - M[2, 2] + 1) * 0.5 * np.sign(M[0, 2] - M[2, 0])
        a4 = math.sqrt(M[2, 2] - M[0, 0] - M[1, 1] + 1) * 0.5 * np.sign(M[1, 0] - M[0, 1])

        return Orient(a1, a2, a3, a4)


class EulerAngles:
    def __init__(self, yaw=0.0, pitch=0.0, roll=0.0, order='zyx'):
        """
        :param yaw:
        :param pitch:
        :param roll:
        :param order:
        """
        self.yaw = yaw  # robot z alpha, MAPS Y
        self.pitch = pitch  # robot y beta, MAPS X
        self.roll = roll  # robot x gamma, MAPS Z

        self.order = order  # order of euler rotations, string !
        self.eulerList = [self.yaw, self.pitch, self.roll]
        self.rot_matrix = None

    def euler_to_quaternion(self) -> Orient:
        """
        Converts euler angles to quaternions (adjusted to ABB systems).
        because we want the tool to be perpendicular to the work object.
        :return: Quaternions
        """
        # Y
        cos1 = np.cos(self.pitch / 2)
        sin1 = np.sin(self.pitch / 2)
        # Z
        cos2 = np.cos(self.yaw / 2)
        sin2 = np.sin(self.yaw / 2)
        # X
        cos3 = np.cos(self.roll / 2)
        sin3 = np.sin(self.roll / 2)

        qw = (cos1 * cos2) * cos3 + (sin1 * sin2) * sin3
        qx = (cos1 * cos2) * sin3 - (sin1 * sin2) * cos3
        qy = (sin1 * cos2 * cos3) + (cos1 * sin2 * sin3)
        qz = (cos1 * sin2 * cos3) - (sin1 * cos2 * sin3)

        quaternions = Orient(round(qw, 6), round(qx, 6), round(qy, 6), round(qz, 6))

        return quaternions

    def rotation_matrix(self, order: str, passive_rotation=False) -> np.array:
        """
        Calculates the rotation matrix by given euler angles and rotation order.
        :param order: rotation order (e.g. 'xyz')
        :param passive_rotation: rotate the basis (passive) or the vectors (active)
        :return: rotation matrix in np.array() style

        The rotation of a basis by the angle theta is equivalent to the rotation of all vectors by the angle
        -theta. http://boris-belousov.net/2016/05/31/change-of-basis
        """
        # this is the rotation matrices for an active rotation (rotating the vectors in a configuration space)
        Rz = np.array([[cos(self.yaw), -sin(self.yaw), 0], [sin(self.yaw), cos(self.yaw), 0], [0, 0, 1]])
        Ry = np.array([[cos(self.pitch), 0, sin(self.pitch)], [0, 1, 0], [-sin(self.pitch), 0, cos(self.pitch)]])
        Rx = np.array([[1, 0, 0], [0, cos(self.roll), -sin(self.roll)], [0, sin(self.roll), cos(self.roll)]])

        # this is the rotation matrices for a passive rotation (rotating the configuration space or change of basis)
        # usually the rotation matrices are inverted, in this case however, transposing them is the same
        if passive_rotation:
            Rz = Rz.T
            Ry = Ry.T
            Rx = Rx.T

        if order == 'zyx':
            Rzy = np.matmul(Rz, Ry)
            Rzyx = np.matmul(Rzy, Rx)
            self.rot_matrix = Rzyx
            return Rzyx, Rx, Ry, Rz

        elif order == 'yzx':
            Ryz = np.matmul(Ry, Rz)
            Ryzx = np.matmul(Ryz, Rx)
            self.rot_matrix = Ryzx
            return Ryzx, Rx, Ry, Rz

        if order == 'xyz':
            Rxy = np.matmul(Rx, Ry)
            Rxyz = np.matmul(Rxy, Rz)
            self.rot_matrix = Rxyz
            return Rxyz, Rx, Ry, Rz

        if order == 'yxz':
            Ryx = np.matmul(Ry, Rx)
            Ryxz = np.matmul(Ryx, Rz)
            self.rot_matrix = Ryxz
            return Ryxz, Rx, Ry, Rz

        else:
            print('Unknown order!')
            return None


class Pose:
    def __init__(self, x=0.0, y=0.0, z=0.0,
                 q0=1.0, q1=0.0, q2=0.0, q3=0.0):
        super(Pose, self).__init__()

        self.pos = Pos(x, y, z)
        self.orient = Orient(q0, q1, q2, q3)

    def __sub__(self, other):
        """
        Override of subtraction method to sub two Points in order to get the deviation between those.
        :param other:
        :return:
        """
        deviation = Pose()
        deviation.pos.x = self.pos.x - other.pos.x
        deviation.pos.y = self.pos.y - other.pos.y
        deviation.pos.z = self.pos.z - other.pos.z

        return deviation

    def __truediv__(self, other):
        """
        Override divide method to divide x, y and z by a value.
        :param other:
        :return:
        """
        new_value = Pose()
        new_value.pos.x = self.pos.x / other
        new_value.pos.y = self.pos.y / other
        new_value.pos.z = self.pos.z / other

        return new_value


class Loaddata:
    def __init__(self):
        super(Loaddata, self).__init__()

        self.mass = 0.001
        self.cog = Pos(0, 0, 0.001)
        self.aom = Orient()
        self.ix = 0.0
        self.iy = 0.0
        self.iz = 0.0


class Workobject:
    def __init__(self):
        super(Workobject, self).__init__()

        self.robhold = False
        self.ufprog = True
        self.ufmec = ""

        self.uframe = Pose()
        self.oframe = Pose()


class Tool:
    def __init__(self):
        super(Tool, self).__init__()

        self.robhold = True
        self.tframe = Pose()
        self.tload = Loaddata()


class PIDFeedback:
    def __init__(self):
        super(PIDFeedback, self).__init__()

        self.x = None
        self.y = None
        self.z = None
        self.yaw = None
        self.pitch = None
        self.roll = None


class PIDOutput:
    def __init__(self):
        super(PIDOutput, self).__init__()

        self.x = None
        self.y = None
        self.z = None
        self.yaw = None
        self.pitch = None
        self.roll = None


class Point:
    def __init__(self, x=0.0, y=0.0, z=0.0, q0=1.0, q1=0.0, q2=0.0, q3=0.0, *args, **kwargs):
        super(Point, self).__init__()

        self.pose = Pose(x, y, z, q0, q1, q2, q3)
        self.scalar = Scalar(self.pose.pos.x, self.pose.pos.y, self.pose.pos.z)

        self.lin_speed = 0.0  # mm/s
        self.rot_speed = 0.0
        self.spindle_speed = 0.0

        # absolute index in path (0 .. len(path))
        self.pl_idx = 0
        # position index in path (repeats if position is measured multiple times in spd mode) eg. [0, 0, 1, 1, 2, 2, ..]
        self.pos_idx = 0

        self.eulerAngles = EulerAngles(0.0, 0.0, 90.0)
        self.timestamp = 0.0
        self.temperature = TemperatureSensor()
        self.type = ''

        for attr in kwargs:
            type_of_self = type(getattr(self, attr))

            if attr == 'pose':
                self.pose = kwargs.get(attr)
            else:
                setattr(self, attr, type_of_self(kwargs.get(attr)))

    def __sub__(self, other):
        """
        Override of subtraction method to subtract a Point (pos and pose) from this Point (inplace)
        :param other:
        :return:
        """
        self.pose.pos.x = self.pose.pos.x - other.pose.pos.x
        self.pose.pos.y = self.pose.pos.y - other.pose.pos.y
        self.pose.pos.z = self.pose.pos.z - other.pose.pos.z

        self.eulerAngles.yaw = self.eulerAngles.yaw - other.eulerAngles.yaw
        self.eulerAngles.pitch = self.eulerAngles.pitch - other.eulerAngles.pitch
        self.eulerAngles.roll = self.eulerAngles.roll - other.eulerAngles.roll

        return self

    def get_scalar(self) -> tuple:
        return self.scalar.x, self.scalar.y, self.scalar.z

    def get_euler_angles(self) -> (float, float, float):
        """
        Returns the euler angles of the TCP
        Returns
        -------

        """
        return self.eulerAngles.yaw, self.eulerAngles.pitch, self.eulerAngles.roll

    def update_scalar(self) -> None:
        self.scalar.x = copy.copy(self.pose.pos.x)
        self.scalar.y = copy.copy(self.pose.pos.y)
        self.scalar.z = copy.copy(self.pose.pos.z)

    def euler_to_quaternion(self) -> None:
        """
        Converts euler angles to quaternions.
        :return: Orient object
        """
        (yaw, pitch, roll) = (self.eulerAngles.yaw, self.eulerAngles.pitch, self.eulerAngles.roll)
        self.pose.orient.q0 = np.sin(roll / 2) * np.cos(pitch / 2) * np.cos(yaw / 2) - np.cos(roll / 2) * np.sin(
            pitch / 2) * np.sin(yaw / 2)
        self.pose.orient.q1 = np.cos(roll / 2) * np.sin(pitch / 2) * np.cos(yaw / 2) + np.sin(roll / 2) * np.cos(
            pitch / 2) * np.sin(yaw / 2)
        self.pose.orient.q2 = np.cos(roll / 2) * np.cos(pitch / 2) * np.sin(yaw / 2) - np.sin(roll / 2) * np.sin(
            pitch / 2) * np.cos(yaw / 2)
        self.pose.orient.q3 = np.cos(roll / 2) * np.cos(pitch / 2) * np.cos(yaw / 2) + np.sin(roll / 2) * np.sin(
            pitch / 2) * np.sin(yaw / 2)

    def quaternion_to_euler(self, as_deg=False) -> None:
        """
        Converts quaternions to euler angles.
        :return: EulerAngles object
        """
        (x, y, z, w) = (self.pose.orient.q0, self.pose.orient.q1, self.pose.orient.q2, self.pose.orient.q3)
        t0 = +2.0 * (w * x + y * z)
        t1 = +1.0 - 2.0 * (x * x + y * y)
        self.eulerAngles.roll = math.atan2(t0, t1)

        t2 = +2.0 * (w * y - z * x)
        t2 = +1.0 if t2 > +1.0 else t2
        t2 = -1.0 if t2 < -1.0 else t2
        self.eulerAngles.pitch = math.asin(t2)

        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        self.eulerAngles.yaw = math.atan2(t3, t4)# + math.pi/2

        if as_deg:
            self.eulerAngles.roll *= 180/math.pi
            self.eulerAngles.pitch *= 180/math.pi
            self.eulerAngles.yaw *= 180/math.pi


def ndarray_as_path(array: np.ndarray):
    path = Path()

    # array should have x, y, z and t values in this order
    if len(array) < 4:
        print('Wrong array length: %s X, Y, Z or Timestamp is missing!' % len(array))
        return None

    # [x[], y[], z[], t[]] --> [x[n], y[n], z[n], t[n]]
    array_T = array.transpose()

    for values in array_T:
        path.append(Point(values[0], values[1], values[2], values[3]))

    return path


class PathList(list):
    def __init__(self):
        super(PathList, self).__init__()

        # total number of all points in all paths if paths in path
        self.points_count = 0
        # number of Path objects in this list
        self.part_count = 0
        # number of measurements per probing position in probing mode
        self.probing_samples = 1
        # selected path type
        self.path_type = None

    def append(self, path) -> None:
        """
        Checks if the appendix is of type Path
        :param path: A Path object
        :return:
        """
        if not isinstance(path, Path):
            raise TypeError('Item is not of type %s, but %s!' % (Path, type(path)))

        else:
            super(PathList, self).append(path)
            self.part_count += 1
            self.points_count += len(path)

    def get_number_of_Points(self) -> int:
        """
        Return the total amount of Points in all the Paths in this list.
        :return:
        """
        return self.points_count

    def get_number_of_parts(self) -> int:
        """
        Returns the number of Paths in this list
        :return:
        """
        return self.part_count

    def to_Path(self):
        """
        Converts PathList to Path
        :return: Path
        """
        path = Path()
        path.probing_samples = self.probing_samples
        path.points_count = self.points_count
        path.path_type = self.path_type

        for part in self:
            path.append(part)

        return path


class Path(list):
    def __init__(self, *args, **kwargs):
        super(Path, self).__init__()

        # total number of all points in all paths if paths in path
        self.points_count = 0
        # number of measurements per probing position in probing mode
        self.probing_samples = 1
        # selected path type
        self.path_type = None

        # check for casting from list containing Points to Path - called by path_planning
        for attr in args:
            if isinstance(attr, list):
                self.cast_list_to_path(attr)

            if isinstance(attr, Point):
                self.append(attr)

            if isinstance(attr, Pos):
                self.append(Point(attr.x, attr.y, attr.z))

        self.__f_x = None
        self.__f_y = None
        self.__f_z = None

    def append(self, pos: object) -> None:
        """
        This method requires a object of the typ Point or Path (extend)
        :param pos: Either a Point or a Path object
        :return:
        """
        if not isinstance(pos, Point) and not isinstance(pos, Path):
            raise TypeError('Item is not of type %s or %s, but %s!' % (Point, Path, type(pos)))

        if isinstance(pos, Point):
            pos.update_scalar()
            super(Path, self).append(pos)
            self.points_count += 1

        elif isinstance(pos, Path):
            super(Path, self).extend(pos)
            self.points_count += len(pos)

    def cast_list_to_path(self, l: list):
        """
        Converts a list containing Points in a Path
        :return: the converted Path
        """
        for point in l:
            if not isinstance(point, Point):
                raise ValueError('List element is not of type Point, but %s' % type(point))

            else:
                self.append(point)

        return self

    def to_3d_pos_list(self, with_ts: bool = False) -> list:
        """
        :return: A N,3|4 list of x, y, and z (and t) coordinates. Mostly used for GUI.
        :param with_ts: with timestamp
        """
        pos_l = []

        if not with_ts:
            for n in range(0, len(self)):
                pos_l.append([self[n].pose.pos.x, self[n].pose.pos.y, self[n].pose.pos.z])
        else:
            for n in range(0, len(self)):
                pos_l.append([self[n].pose.pos.x, self[n].pose.pos.y, self[n].pose.pos.z, self[n].timestamp])

        return pos_l

    def to_separate_lists(self) -> tuple:
        """
        Casts path to 4 separate lists storing x, y, z and timestamp data.
        @param with_ts:
        @return:
        """
        data_x = []
        data_y = []
        data_z = []
        data_ts = []

        for n in range(0, len(self)):
            data_x.append(self[n].pose.pos.x)
            data_y.append(self[n].pose.pos.y)
            data_z.append(self[n].pose.pos.z)
            data_ts.append(self[n].timestamp)

        return data_x, data_y, data_z, data_ts

    def to_dataframe(self, col_names: list = None) -> pd.DataFrame:
        """
        Converts the path to a DataFrame object. Column names can be given optionally.
        @return:
        """
        if col_names is not None:
            return pd.DataFrame(data=self.to_3d_pos_ndarray(), columns=col_names)

        else:
            return pd.DataFrame(data=self.to_3d_pos_ndarray())

    def to_3d_pos_ndarray(self, with_ts: bool = False) -> np.ndarray:
        """
        Converts the N,3|4 list into a numpy array.
        :param with_ts: with timestamp
        :return:
        """
        pos_l = self.to_3d_pos_list(with_ts)
        pos_ndarray = np.asarray(pos_l)
        return pos_ndarray

    def to_PathList(self, part_size: int) -> PathList:
        """
        Converts the Path to a PathList. Only part size is needed for that.
        @return:
        """
        path_list = PathList()

        path_point_len = self.points_count
        path_list.path_type = self.path_type
        rest = path_point_len % part_size
        part_count = 0

        # build new path, part for part
        for n in range(part_size, path_point_len + 1, part_size):
            off = n - part_size
            # cast part (list containing Points) to Path
            part = Path(self[off:n])

            # self.mw.s_plot_planned_path.emit(part, 0)
            path_list.append(part)
            part_count += 1

        # also transfer the rest
        if rest > 0:
            # cast part (list containing Points) to Path
            part = Path(self[path_point_len - rest:path_point_len + 1])
            # self.mw.s_plot_planned_path.emit(part, 0)
            path_list.append(part)
            part_count += 1

        path_list.part_count = part_count
        return path_list

    def coord_mean(self) -> Point:
        """
        Calculates the mean value of all members of x, y and z (and t).
        :return: Point of mean values
        """
        array = self.to_3d_pos_ndarray()
        mean = array.mean(axis=0)
        return Point(mean[0], mean[1], mean[2])

    def std(self) -> Point:
        """
        Calculates the standard deviation of each x, y, and z in the path.
        TODO: Shapiro-Wilk Test um zu überprüfen ob Werte normalverteilt sind!
        :return: Point of std values
        """
        array = self.to_3d_pos_ndarray()
        std = array.std(axis=0)
        return Point(std[0], std[1], std[2])

    def interpolate_path(self):
        """
        Set up the interpolation function for the current path.
        :return:
        """
        # convert planned path to a list, in order to feed them for interpolation
        planned_path_ndarray = self.to_3d_pos_ndarray(with_ts=True).transpose()

        if len(planned_path_ndarray) == 4:
            try:
                # interpolation functions
                self.__f_x = spi.interp1d(planned_path_ndarray[3], planned_path_ndarray[0], fill_value="extrapolate")
                self.__f_y = spi.interp1d(planned_path_ndarray[3], planned_path_ndarray[1], fill_value="extrapolate")
                self.__f_z = spi.interp1d(planned_path_ndarray[3], planned_path_ndarray[2], fill_value="extrapolate")

            except ValueError:
                print('Planned path seems to be empty! Maybe the given numbers for path planning were wrong.')

    def get_planned_pose_by_ts(self, timestamp: float) -> Point | None:
        """
        Return the interpolated planned pose to a given timestamp.
        :param timestamp: timestamp when an image was taken
        :return: interpolated planned pose
        """
        # check if the interpolation has worked
        if self.__f_x is not None and self.__f_y is not None and self.__f_z is not None:
            # calculate pose values, functions return np arrays
            current_planned_pose = Point()
            current_planned_pose.pose.pos.x = float(self.__f_x(timestamp))
            current_planned_pose.pose.pos.y = float(self.__f_y(timestamp))
            current_planned_pose.pose.pos.z = float(self.__f_z(timestamp))
            current_planned_pose.timestamp = timestamp

            return current_planned_pose

        else:
            return None

    def get_pose_by_ts(self, timestamp: float) -> Point | None:
        """
        Returns Paths pose at given timestamp. ATTENTION: the given timestamp is converted into an integer,
        which means that the last pose to the given timestamp is returned.
        :param timestamp: Timestamp as float
        :return:
        """
        # convert timestamp to int. This also makes sure always the pose before the timestamp is returned
        ts = int(timestamp)
        pose = None

        if timestamp > self[-1].timestamp or timestamp < 0:
            return None

        # start in the middle of the path
        middle_idx = int(len(self) / 2)
        middle_pose = self[middle_idx]

        # decide if up or down
        if ts > round(middle_pose.timestamp, 3):
            for k in range(middle_idx, len(self)):
                if round(self[k].timestamp, 3) == ts:
                    pose = self[k]

        else:
            for n in range(middle_idx - 1, 0 - 1, -1):
                if round(self[n].timestamp, 3) == ts:
                    pose = self[n]

        if pose is None:
            print('No pose found in the path at timestamp %s' % ts)
            return None

        else:
            return pose

    def get_idx_by_ts(self, timestamp: float) -> int | None:
        """
        Returns Paths pose index at given timestamp. ATTENTION: the given timestamp is converted into an integer,
        which means that the last pose to the given timestamp is returned.
        :param timestamp: Timestamp as float
        :return:
        """
        # convert timestamp to int. This also makes sure always the pose before the timestamp is returned
        ts = int(timestamp)
        index = None

        # start in the middle of the path
        middle_idx = int(len(self) / 2)
        middle_pose = self[middle_idx]

        # decide if up or down
        if ts > middle_pose.timestamp:
            for k in range(middle_idx, len(self)):
                if self[k].timestamp == ts:
                    index = k

        else:
            for n in range(middle_idx - 1, 0 - 1, -1):
                if self[n].timestamp == ts:
                    index = n

        if index is None:
            print('No pose found in the path at timestamp %s' % ts)

        else:
            return index


class TemperatureSensor:
    def __init__(self):

        self.temperature0 = None
        self.temperature1 = None
        self.temperature2 = None
        self.temperature_cam_sensor = None

    def set_temperature(self, sensor: int, temperature: float) -> None:
        """
        Function to set temperature to temp object of point object
        :param sensor: Target sensor number (0-2) or cam sensor (3)
        :param temperature: temperature value as float
        :return: -
        """
        if sensor is not None and temperature is not None:
            if sensor == 0:
                self.temperature0 = temperature
            elif sensor == 1:
                self.temperature1 = temperature
            elif sensor == 2:
                self.temperature2 = temperature
            elif sensor == 3:
                self.temperature_cam_sensor = temperature
            else:
                print("Unknown Sensor!")

    def get_temperature_LED(self):
        """
        Return a list with the LED tempterature values.
        """
        return [self.temperature0, self.temperature1, self.temperature2]


def get_selected_leds(mw) -> list:
    """
    Returns a list with three elements - 0 or 1 depends on if the corresponding LED was selected or not.
    :return:
    """
    led0_selected = 1 if mw.rbLed0_toggle.isChecked() else 0
    led1_selected = 1 if mw.rbLed1_toggle.isChecked() else 0
    led2_selected = 1 if mw.rbLed2_toggle.isChecked() else 0

    return [led0_selected, led1_selected, led2_selected]


class LEDIndex:
    def __init__(self):
        # Add more events here if you added more physical LEDs
        self.e_led0_active = Event()
        self.e_led1_active = Event()
        self.e_led2_active = Event()

        self.led_events = [self.e_led0_active, self.e_led1_active, self.e_led2_active]
        self.selected_leds = None

    def set_led_state_event(self, led: int, mode: bool) -> None:
        """
        Set or clear one of the LED events. They indicate if an LED is currently on or off.
        :param led:
        :param mode:
        :return:
        """
        if mode:
            self.led_events[led].set()
        else:
            self.led_events[led].clear()

    def get_active_leds(self) -> list:
        """
        Returns a list with three elements - 0 or 1 depends on the CURRENT status (ON or OFF) of the corresponding LED.
        :return:
        """
        led0_active = 1 if self.e_led0_active.is_set() else 0
        led1_active = 1 if self.e_led1_active.is_set() else 0
        led2_active = 1 if self.e_led2_active.is_set() else 0

        return [led0_active, led1_active, led2_active]

    @staticmethod
    def get_selected_leds(window) -> list:
        """
        Returns a list with three elements - 0 or 1 depends on if the corresponding LED was selected or not.
        :return:
        """
        led0_selected = 1 if window.rbLed0_toggle.isChecked() else 0
        led1_selected = 1 if window.rbLed1_toggle.isChecked() else 0
        led2_selected = 1 if window.rbLed2_toggle.isChecked() else 0

        return [led0_selected, led1_selected, led2_selected]


class PathRequest:
    """
    Used to store the parameters of a path (pointlist) request. This is used by the machine control
    quick and dirty path planning to place a request at path planning thread.
    """
    def __init__(self):
        # what kind of path is this, e.g. line, meander or sphere
        self.path_type = None
        # probing mode means, that each position can be approached multiple times
        self.is_probing_mode = False
        # how many approaches per position
        self.num_probing = 1
        # where the line, meander starts
        self.start_position = Scalar()
        # and where it ends
        self.end_position = Scalar()
        # if a mesh is created, an origin position is needed
        self.origin_position = Scalar()
        # how many points are transmitted to the machine at once
        self.part_size = None
        # step size per axis
        self.step_size = Scalar()
        # machine linear speed
        self.linear_speed = 50.
        # machine rotation axis speed (robots only)
        self.rot_speed = 90.

        # z offset for milling or polishing to make the robot start the path above the workpiece
        # z offset value
        self.z_offset_value = 0.
        # if False, the machine sends its current position whenever it reaches a planned position (MoveLDO)
        # if True, it does only send the position if it is requested (MoveL)
        self.poll_machine_pos = False

        # radius for spherical mesh
        self.mesh_radius = 0.


class Intersection:
    def __init__(self, x, y, z, radius, intensity):
        self.x = x
        self.y = y
        self.z = z
        self.radius = radius
        self.intensity = intensity

    def to_list(self) -> list:
        """
        Returns all attributes as a list.
        @return:
        """
        return [self.x, self.y, self.z, self.radius, self.intensity]


class Intersections(list):
    def __init__(self):
        super().__init__()

        self.intersection: list[Intersection] = list()

    def __append__(self, other: Intersection) -> None:
        self.append(other)

    def to_np_array(self) -> np.array:
        inters = []
        for inter in self:
            inters.append(inter.to_list())

        return np.asarray(inters)

    def to_mlx_array(self):
        from pandora.GLOBALS import MLX_AVAILABLE, mx
        if not MLX_AVAILABLE:
            return None

        inters = []
        for inter in self:
            inters.append(inter.to_list())

        return mx.array(inters)
